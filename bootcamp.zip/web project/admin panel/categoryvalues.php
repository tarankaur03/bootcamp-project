<?php
$con=mysqli_connect("localhost","root","","bags");
if(isset($_POST['submit']))
{
    $cat_name=$_POST['cat_name'];
    $data="insert into category(cat_id,cat_name,cat_publisheddate) values ('','$cat_name',now())";
    $query=mysqli_query($con,$data);
    if($query)
    {  
               header("Location:cat_view.php");   
    }
    else{
               echo "Record not inserted";  
             
    }
}
?>