<?php 
$con=mysqli_connect("localhost","root","","test");
if(isset($_POST['submit'])){
    $a=$_POST['username'];
    $b=$_POST['password'];
    
    $q="select * from login2 where username='$a' and password='$b'";
    $query=mysqli_query($con,$q);
    $row=mysqli_fetch_assoc($query);
    if($row){
        echo "ok";
    }
    else{
        echo "error";
    }
}
?>