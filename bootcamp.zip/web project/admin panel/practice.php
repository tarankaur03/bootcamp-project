<form action="practicecode.php" method="post" name="form">
    <h1> login form </h1>
         <div class="form-outline mb-4">
         <input type="text" id="form2Example17" class="form-control form-control-lg" name="username"/>
         <label class="form-label" for="form2Example17">Username</label>
         </div>
         <div class="form-outline mb-4">
         <input type="password" id="form2Example27" class="form-control form-control-lg" name="password" />
         <label class="form-label" for="form2Example27">Password</label>
         </div>
         <div class="pt-1 mb-4">
         <button class="btn btn-dark btn-lg btn-block" type="submit" name="submit">Login</button>
         </div>
</form>