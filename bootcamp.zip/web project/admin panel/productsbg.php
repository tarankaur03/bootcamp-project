<?php
$con=mysqli_connect("localhost","root","","bags");
if(isset($_POST['submit']))
{
    $pcat_name=$_POST['pcat_name'];
    $id=$_GET['id'];
    $data2="update products set pcat_name='$pcat_name' where prod_id='$id'";
    $query=mysqli_query($con,$data2);
    if($query)
    {  
               header("Location:prod_view.php");    
    }
    else
    {
               echo "Record not updated";  
             
    }
}
?>