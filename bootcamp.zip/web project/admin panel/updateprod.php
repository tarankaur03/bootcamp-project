<?php
session_start();
if($_SESSION['username']=="")
{
  header('Location:index.php');
}
$con=mysqli_connect("localhost","root","","bags");
$id=$_GET['id'];
$q="select * from products where prod_id=$id";
$query=mysqli_query($con,$q);
if(mysqli_num_rows($query)>0)
{
    $row=mysqli_fetch_assoc($query);
}
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css'>
  <link rel="stylesheet" href="CSS/style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div class='dashboard'>
    <div class="dashboard-nav">
        <header>
            <a href="#!" class="menu-toggle"><i class="fas fa-bars"></i></a><a href="#" class="brand-logo">
            <i class="fas fa-anchor"></i> <span>THE ICONIC</span></a>
        </header>
        <?php include('sidebar.php')?>
    </div>
    <div class='dashboard-app'>
        <header class='dashboard-toolbar'><a href="#!" class="menu-toggle"><i class="fas fa-bars"></i></a></header>
        <div class='dashboard-content'>
            <div class='container'>
                <div class='card'>
                    <div class='card-header'>
                        <h1 style="color:blue;">UPDATE PRODUCTS</h1>
                    </div>
                    <div class='card-body'>
                       
                        <!DOCTYPE html>
                        <html lang="en" xmlns="http://www.w3.org/1999/xhtml">
                        <head>
                            <meta charset="utf-8" />
                            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
                            <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
                            <link rel="stylesheet" href="products.css" >
                            <title></title>
                        </head>
                        <body>
                        <div class="container">
                            <div class="row">
                            
                            <div class="col-md-6 m-auto" >
                        <form class="products" method="post" action="updatebg.php?id=<?php echo $row['prod_id']?>">
                                <div class="form-group mt-3">
                                    <label for="CATEGORY">Category:</label>
                                    <input type="text" name="pcat_name" class="form-control" value="<?php echo $row['pcat_name']?>">
                                </div>

                                <div class="form-group mt-3">
                                    <label for="BRAND">Brand:</label>
                                    <input type="text" name="brand" class="form-control" value="<?php echo $row['brand']?>">
                                </div>

                                <div class="form-group mt-3">
                                    <label for="COLOR">Color:</label>
                                    <input type="text" name="color" class="form-control" value="<?php echo $row['color']?>">
                                </div>

                                <div class="form-group mt-3">
                                    <label for="DESCRIPTION">Description:</label>
                                    <input type="text" name="description" class="form-control" value="<?php echo $row['description']?>">
                                </div>

                                <div class="form-group mt-3">
                                    <label for="PRICE">Price:</label>
                                    <input type="number" name="price" class="form-control" value="<?php echo $row['price']?>">
                                </div>
                                <div class="form-group mt-3">
                                    <label for="QTY">Qty:</label>
                                    <input type="number" name="qty" class="form-control" value="<?php echo $row['qty']?>">
                                </div>
                                <div class="form-group mt-3">
                                    <label for="img">Select image:</label>
                                    <input type="file" name="img" accept="image/*" class="form-control" value="<?php echo $row['img']?>">
                                </div>

                                <div class="form-group text-center mt-3" >
                                    <button type="submit" name="submit" style="background-color:blue;" class="btn btn-success btn-lg px-5 border-0 rounded-0 " value="SUBMIT" >SUBMIT</button>
                                </div>
                        </form>
                        </div>
                        </div>
                        </div>
                        </body>
                        </html>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js'></script><script  src="JS/script.js"></script>

</body>
</html>