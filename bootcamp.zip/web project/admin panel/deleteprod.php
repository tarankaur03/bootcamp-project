<?php
   session_start();
   if($_SESSION['username']=="")
   {
     header('Location:index.php');
   }
   $con=mysqli_connect("localhost","root","","bags");
   $id=$_GET['id'];
   $q2="delete from products where prod_id='$id'";
   $query2=mysqli_query($con,$q2);
   if($query2)
   {
      header("Location:prod_view.php");
   }
   else
   {
      echo "record not deleted";
   } 
?>
