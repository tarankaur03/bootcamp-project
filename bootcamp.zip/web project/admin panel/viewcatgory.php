        <div class='dashboard-content'>
            <div class='container'>
                <div class='card'>
                    <div class='card-header'>
                        <h1 style="color:blue;">VIEW CATEGORY</h1>
                    </div>
                    <div class='card-body'>
    
                    <?php $con=mysqli_connect("localhost","root","","bags");
                        $q="select * from category";
                        $query=mysqli_query($con,$q);
                    ?>

                    <html>                          
                    <head>
                    <meta charset="utf-8" />
                    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
                    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
                    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
                    <title></title>
                    </head>
                        <body>
                      
                            <table class="table table-striped">
                          <thead>
                            <tr>
                              <th scope="col">Cat_id</th>
                              <th scope="col">Cat_name</th>
                              <th scope="col">Publish_date</th>
                              <th scope="col">Action</th>
                            </tr>
                          </thead>
                          <tbody>
                          <?php
                          $no=1;
                          if (mysqli_num_rows($query) > 0) {
                          while($row=mysqli_fetch_assoc($query))
                        {
                  
                        ?>

                            <tr>
                              <th scope="row"><?php echo $no++ ;?></th>
                              <td><?php echo $row['cat_name']?></td>
                              <td><?php echo $row['cat_publisheddate']?></td>
                              <td><a href="deletecat.php?id=<?php echo  $row['cat_id']?>"><span id="boot-icon" class="bi bi-trash" style="font-size: 2rem; color: rgb(255, 0, 0);"></a><a href="updatecat.php?id=<?php echo  $row['cat_id']?>"><span id="boot-icon" class="bi bi-pen" style="font-size: 2rem; color: rgb(255, 0, 0);"></span></a></td>
                            </tr>
                        <?php
                        }
                        }?>

                        </tbody>
                        </table>
                        </body>
                        </html>
                    </div>
                </div>
            </div>
        </div>