<?php
   $con=mysqli_connect("localhost","root","","bags");
   $id=$_GET['id'];
   $q2="delete from category where cat_id='$id'";
   $query2=mysqli_query($con,$q2);
   if($query2)
   {
    header("Location:cat_view.php");
   }
   else
   {
    echo "record not deleted";
   } 
?>
