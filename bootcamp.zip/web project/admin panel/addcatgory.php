        <div class='dashboard-content'>
            <div class='container'>
                <div class='card'>
                    <div class='card-header'>
                        <h1 style="color:blue;">INSERT CATEGORY</h1>
                    </div>
                    <div class='card-body'>
                        
                        <!DOCTYPE html>
                        <html lang="en" xmlns="http://www.w3.org/1999/xhtml">
                        <head>
                            <meta charset="utf-8" />
                            <link rel="stylesheet">
                            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
                            <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
                            <title></title>
                        </head>
                        <body>
                            <div class="container">
                            <div class="row">
                            
                            <div class="col-md-6 m-auto">
                                <form class="categories" method="post" action="categoryvalues.php">
                                    <div class="form-group mt-3">
                                        <label for="CATEGORY" >Category:</label>
                                        <input type="text" name="cat_name" class="form-control">
                                    </div>
                                        <div class="form-group text-center mt-3" >
                                        <button type="submit" name="submit" style="background-color:blue;"class="btn btn-success btn-lg px-5 border-0 rounded-0" value="submit">SUBMIT</button>
                                    </div>
                                    </form>
                            </div>
                            </div>
                            </div>
                        </body>
                        </html>
                    </div>
                </div>
            </div>
        </div>