 <nav class="dashboard-nav-list">
         <a href="dashboard.php" class="dashboard-nav-item"><i class="fas fa-home"></i>Home </a>
              <div class='dashboard-nav-dropdown'>
                     <a href="#!" class="dashboard-nav-item dashboard-nav-dropdown-toggle"><i class="fas fa-photo-video"></i> Category </a>
                            <div class='dashboard-nav-dropdown-menu'>
                                <a href="cat_insert.php" class="dashboard-nav-dropdown-item">INSERT</a>
                                <a href="cat_view.php" class="dashboard-nav-dropdown-item">VIEW</a>     
                            </div>
             <div class='dashboard-nav-dropdown'>
                     <a href="#!" class="dashboard-nav-item dashboard-nav-dropdown-toggle"><i class="fas fa-users"></i> Products </a>
                           <div class='dashboard-nav-dropdown-menu'>
                                <a href="prod_insert.php" class="dashboard-nav-dropdown-item">INSERT</a>
                                <a href="prod_view.php" class="dashboard-nav-dropdown-item">VIEW</a>
            </div>
            
            <!--<div class='dashboard-nav-dropdown'>
                   <a href="#!" class="dashboard-nav-item dashboard-nav-dropdown-toggle"><i class="fas fa-money-check-alt"></i> Payments </a>
                         <div class='dashboard-nav-dropdown-menu'>
                               <a href="#" class="dashboard-nav-dropdown-item">INSERT</a>
                               <a href="#" class="dashboard-nav-dropdown-item">VIEW</a>
                        </div>
            </div>
            <a href="#" class="dashboard-nav-item"><i class="fas fa-cogs"></i> Settings </a>
            <a href="#" class="dashboard-nav-item"><i class="fas fa-user"></i> Profile </a>--> 
            <div class="nav-item-divider"></div>
            <a href="logout.php" class="dashboard-nav-item"><i class="fas fa-sign-out-alt"></i> Logout </a>
</nav>