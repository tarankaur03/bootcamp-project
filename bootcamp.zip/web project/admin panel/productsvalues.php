﻿<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
</head>
<body>
<?php
     $con=mysqli_connect("localhost","root","","bags");
     if(isset($_POST['submit']))
     {
         $pcat_name=$_POST['pcat_name'];
         $brand=$_POST['brand'];
         $color=$_POST['color'];
         $description=$_POST['description'];
         $price=$_POST['price'];
         $qty=$_POST['qty'];
         $img= $_FILES["img"]["name"] ;
        if (!file_exists("upload/" . $_FILES["img"]["name"]))
        {
     
         move_uploaded_file($_FILES["img"]["tmp_name"],"upload/" . $_FILES["img"]["name"]);
         $data="insert into products(prod_id,pcat_name,brand,color,description,price,qty,img) values ('','$pcat_name','$brand','$color','$description','$price','$qty','$img')";
         $query=mysqli_query($con,$data);
         if($query)
         {  
                    header("Location:prod_view.php");  
         }
         else
         {
                    echo "Record not inserted";  
                  
         }
     }
    }
    
     ?>
</body>
</html>