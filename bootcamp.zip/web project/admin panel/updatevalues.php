<?php
$con=mysqli_connect("localhost","root","","bags");
if(isset($_POST['submit']))
{
    $cat_name=$_POST['cat_name'];
    $id=$_GET['id'];
    $data2="update category set cat_name='$cat_name' where cat_id='$id'";
    $query=mysqli_query($con,$data2);
    if($query)
    {  
               header("Location:cat_view.php");
    }
    else
    {
               echo "Record not updated";  
             
    }
}
?>