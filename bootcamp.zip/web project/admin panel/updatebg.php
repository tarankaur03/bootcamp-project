<?php
$con=mysqli_connect("localhost","root","","bags");
if(isset($_POST['submit']))
{
    $pcat_name=$_POST['pcat_name'];
    $brand=$_POST['brand'];
    $color=$_POST['color'];
    $description=$_POST['description'];
    $price=$_POST['price'];
    $qty=$_POST['qty'];
    $img=$_POST['img'];

    $id=$_GET['id'];
    $data2="update products set pcat_name='$pcat_name', brand='$brand',color='$color',description='$description',price='$price',qty='$qty',img='$img' where prod_id='$id'";
    $query=mysqli_query($con,$data2);
    if($query)
    {  
               header("Location:prod_view.php"); 
    }
    else
    {
               echo "Record not updated";  
             
    }
}
?>