<html>                          
   <head>
      <meta charset="utf-8" />
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <title></title>
    </head>
        <body>
          <div class='dashboard-content'>
              <div class='container'>
                <div class='card'>
                  <div class='card-header'>
                      <h1 style="color:blue;">VIEW PRODUCTS</h1>
                  </div>
                  <div class='card-body'>
                      <table class="table table-striped">
                        <thead>
                          <tr>
                            <th scope="col">S.No</th>
                            <th scope="col">Pcat_name</th>
                            <th scope="col">Brand</th>
                            <th scope="col">Color</th>
                            <th scope="col">Description</th>
                            <th scope="col">Price</th>
                            <th scope="col">Qty</th>
                            <th scope="col">Img</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>
                                    <tbody>
                                            <?php
                                            
                                                if (isset($_GET['pageno'])) {
                                                  $pageno = $_GET['pageno'];
                                              } else {
                                                  $pageno = 1;
                                              }
                                                $no_of_records_per_page = 5;
                                                $offset = ($pageno-1) * $no_of_records_per_page;
                                      
                                                $conn=mysqli_connect("localhost","root","","bags");
                                                $total_pages_sql = "SELECT COUNT(*) FROM products";
                                                $result = mysqli_query($conn,$total_pages_sql);
                                                $total_rows = mysqli_fetch_array($result)[0];
                                                $total_pages = ceil($total_rows / $no_of_records_per_page);
                                                $sql = "SELECT * FROM products LIMIT $offset, $no_of_records_per_page";
                                                $query = mysqli_query($conn,$sql);
                                                $no=1;
                                                while($row = mysqli_fetch_array($query)){
                                                    //here goes the data    
                                            ?>
                                                <tr>
                                                  <th scope="row"><?php echo $no++ ;?></th>
                                                  <td><?php echo $row['pcat_name']?></td>
                                                  <td><?php echo $row['brand']?></td>
                                                  <td><?php echo $row['color']?></td>
                                                  <td><?php echo $row['description']?></td>
                                                  <td><?php echo $row['price']?></td>
                                                  <td><?php echo $row['qty']?></td>
                                                  <td><img width=100px height=100px src='upload/<?php echo $row["img"]?>'></td>
                                                  <td><a href="deleteprod.php?id=<?php echo  $row['prod_id']?>"><span id="boot-icon" class="bi bi-trash" style="font-size: 2rem; color: rgb(255, 0, 0);"></a>
                                                  <a href="updateprod.php?id=<?php echo  $row['prod_id']?>"><span id="boot-icon" class="bi bi-pen" style="font-size: 2rem; color: rgb(255, 0, 0);"></span></a></td>
                                                </tr>
                                            <?php
                                            }
                                            ?>

                        </tbody>
                        </table>
                        <ul class="pagination">
                              <li><a href="?pageno=1">First</a></li>
                              <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
                                  <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>">Prev</a>
                              </li>
                              <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
                                  <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>">Next</a>
                              </li>
                              <li><a href="?pageno=<?php echo $total_pages; ?>">Last</a></li>
                          </ul>
                        </body>
                        </html>
                    </div>
                </div>
            </div>
        </div>